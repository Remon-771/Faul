# Sunshine Public School Management System

A comprehensive, professional web-based school management system with full JavaScript functionality.

## 🎓 Features

### Core Functionality
- **Class Routine Management**: Complete room and schedule management system
- **Student Portal**: Student login and dashboard access
- **Teacher Portal**: Faculty login and management tools
- **Admission System**: Online application form with validation
- **Authentication**: Multi-role login system (Student/Teacher/Admin)
- **Data Management**: Local storage with export/import capabilities

### Technical Features
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Professional UI/UX**: Modern glassmorphism design with smooth animations
- **Data Persistence**: Browser localStorage for data management
- **Export Functionality**: JSON export and printable schedules
- **Keyboard Shortcuts**: Professional keyboard navigation
- **Error Handling**: Comprehensive validation and user feedback
- **Accessibility**: ARIA labels and keyboard navigation support

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server required - runs completely client-side

### Installation
1. Download or clone the project files
2. Open `index.html` in your web browser
3. The system will automatically initialize with sample data

### File Structure
```
Final_Project/
├── index.html          # Home page
├── login.html          # Login portal
├── admission.html      # Admission form
├── routine.html        # Class routine management
├── student.html        # Student portal
├── teacher.html        # Teacher portal
├── output.css          # Tailwind CSS styles
├── input.css           # Custom CSS input
├── package.json        # Node.js dependencies
├── js/
│   └── school-system.js # Main JavaScript system
└── pic/                # Image assets
```

## 📋 Usage Guide

### Default Login Credentials

#### Admin Access
- **Username**: `admin`
- **Password**: `admin123`
- **Access**: Full routine management

#### Student Access
- **Username**: `STU001`
- **Password**: `student123`
- **Access**: Student portal

#### Teacher Access
- **Username**: `TEA001`
- **Password**: `teacher123`
- **Access**: Teacher portal

### Key Features

#### 1. Routine Management
- Add/Edit/Delete rooms with different categories (Classroom, Lab, Other)
- Create time slots with conflict detection
- Schedule classes with teacher and subject assignment
- Visual room cards with facility information
- Export schedules to JSON or print

#### 2. Room Management
- **Classroom**: Standard teaching rooms with projector, whiteboard, AC
- **Laboratory**: Science labs with equipment and safety features
- **Other Rooms**: Library, auditorium, etc. with custom facilities
- Capacity management (min/max students)
- Floor and status tracking

#### 3. Authentication System
- Role-based access control
- Session management with localStorage
- Secure login validation
- Automatic redirection based on user role

#### 4. Admission System
- Complete application form with validation
- Age verification based on grade level
- Email and phone validation
- Application tracking with unique IDs
- Success confirmation with application details

### 🎯 Keyboard Shortcuts

| Shortcut | Action |
|----------|---------|
| `Ctrl + N` | Add New Room |
| `Ctrl + T` | Add Time Slot |
| `Ctrl + P` | Print Schedule |
| `Ctrl + E` | Export Data |
| `Ctrl + H` | Show Keyboard Shortcuts |
| `Ctrl + F` | Focus Search |
| `Ctrl + M` | Manage Rooms |
| `Esc` | Close Modal |

## 🔧 Technical Implementation

### JavaScript Architecture
- **Class-based design**: `SchoolManagementSystem` main class
- **Event-driven**: Comprehensive event handling system
- **Modular functions**: Separate methods for each feature
- **Data persistence**: localStorage with JSON serialization
- **Error handling**: Try-catch blocks with user feedback

### Key JavaScript Features
```javascript
// Main system initialization
const schoolSystem = new SchoolManagementSystem();

// Data management
schoolSystem.rooms        // Room data array
schoolSystem.timeSlots    // Time slot data array
schoolSystem.schedules    // Schedule map
schoolSystem.users        // User authentication map
schoolSystem.admissions   // Admission applications array

// Core methods
schoolSystem.openModal(modalId)
schoolSystem.closeModal(modalId)
schoolSystem.showNotification(message, type)
schoolSystem.exportData(format)
schoolSystem.printSchedule()
```

### CSS Framework
- **Tailwind CSS**: Utility-first CSS framework
- **Custom animations**: Keyframe animations for enhanced UX
- **Responsive design**: Mobile-first breakpoints
- **Glassmorphism**: Modern backdrop-blur effects
- **Professional color scheme**: Blue/purple gradient palette

## 📱 Responsive Design

### Breakpoints
- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px+

### Mobile Features
- Hamburger menu navigation
- Touch-friendly buttons
- Optimized modal sizes
- Swipe-friendly interfaces
- Compressed layouts

## 🎨 Design System

### Color Palette
- **Primary**: Blue (#3b82f6)
- **Secondary**: Purple (#8b5cf6)
- **Success**: Green (#10b981)
- **Warning**: Yellow (#f59e0b)
- **Error**: Red (#ef4444)
- **Gray Scale**: Various gray shades for text and backgrounds

### Typography
- **Font Family**: System font stack (sans-serif)
- **Headings**: Bold weights with appropriate sizing
- **Body Text**: Regular weight with optimal line height
- **Code**: Monospace for technical elements

## 🔒 Security Features

### Data Protection
- Client-side only (no server vulnerabilities)
- localStorage encryption consideration
- Input validation and sanitization
- XSS prevention through proper escaping

### Authentication
- Password validation
- Role-based access control
- Session timeout handling
- Secure credential storage

## 🚀 Performance Optimization

### Loading
- Efficient DOM manipulation
- Event delegation
- Lazy loading for animations
- Minimal JavaScript execution on page load

### Memory Management
- Proper event listener cleanup
- Efficient data structures (Map for O(1) lookups)
- Garbage collection friendly code
- localStorage size management

## 🔧 Customization

### Adding New Features
1. Extend the `SchoolManagementSystem` class
2. Add new methods for functionality
3. Update the HTML with required form elements
4. Add event listeners in `setupFormEvents()`

### Styling Modifications
1. Update `input.css` for custom styles
2. Build with Tailwind CLI: `npx tailwindcss -i input.css -o output.css --watch`
3. Use Tailwind utility classes for rapid styling

### Data Structure Extensions
```javascript
// Example: Adding new room facilities
room.facilities.push('smart_board', 'sound_system', 'recording_equipment');

// Example: Adding new user roles
this.users.set('PRIN001', {
    id: 'PRIN001',
    role: 'principal',
    name: 'Dr. Principal',
    // ... other properties
});
```

## 🧪 Testing

### Manual Testing Checklist
- [ ] Room creation with all categories
- [ ] Time slot creation with conflict detection
- [ ] Schedule assignment and conflicts
- [ ] Login with different user roles
- [ ] Admission form validation
- [ ] Export and print functionality
- [ ] Mobile responsiveness
- [ ] Keyboard shortcuts
- [ ] Error handling scenarios

### Browser Compatibility
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

## 📊 Data Management

### localStorage Keys
- `school_rooms`: Room data array
- `school_timeSlots`: Time slot data array
- `school_schedules`: Schedule map entries
- `school_users`: User authentication map
- `school_admissions`: Admission applications
- `school_currentUser`: Currently logged-in user

### Data Export Format
```json
{
  "rooms": [...],
  "timeSlots": [...],
  "schedules": [...],
  "admissions": [...],
  "exportDate": "2025-01-01T00:00:00.000Z",
  "version": "1.0"
}
```

## 🛠️ Development

### Build Process
```bash
# Install dependencies
npm install

# Build CSS
npx tailwindcss -i input.css -o output.css --watch

# Development server (optional)
npx live-server
```

### Code Structure
- **Separation of Concerns**: HTML structure, CSS styling, JS functionality
- **DRY Principle**: Reusable methods and components
- **SOLID Principles**: Single responsibility, open/closed, dependency inversion
- **Clean Code**: Meaningful names, small functions, clear comments

## 📈 Future Enhancements

### Planned Features
- [ ] Database integration (MongoDB/MySQL)
- [ ] Real-time notifications
- [ ] Advanced reporting system
- [ ] Parent portal integration
- [ ] Grade management system
- [ ] Attendance tracking
- [ ] Fee management
- [ ] Event calendar
- [ ] Email notifications
- [ ] Multi-language support

### Technical Improvements
- [ ] Service Worker for offline functionality
- [ ] Progressive Web App (PWA) features
- [ ] API integration capabilities
- [ ] Advanced caching strategies
- [ ] Performance monitoring
- [ ] Unit testing suite
- [ ] CI/CD pipeline
- [ ] Docker containerization

## 🤝 Contributing

### Development Guidelines
1. Follow existing code style and patterns
2. Add comments for complex functionality
3. Test thoroughly across different browsers
4. Ensure mobile responsiveness
5. Validate accessibility compliance

### Code Review Process
1. Create feature branch from main
2. Implement changes with proper testing
3. Submit pull request with detailed description
4. Address review feedback
5. Merge after approval

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👥 Authors

- **AL AMIN REMON** - Initial development and system architecture

## 🙏 Acknowledgments

- Tailwind CSS for the utility-first CSS framework
- Font Awesome for icons and symbols
- Modern web standards for responsive design principles
- Educational institutions for requirements inspiration

---

**Professional School Management System** - Built with ❤️ for educational excellence