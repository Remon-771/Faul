# 🎓 School Routine Management System

A comprehensive, modern web-based school routine management system built with **Tailwind CSS** and **Vanilla JavaScript**. This system provides three distinct modules for managing and viewing school schedules efficiently.

## ✨ Features

### 🔧 Administration Module
- **Room Management**: Add, edit, and delete rooms with categories (Classroom, Lab, Other)
- **Time Slot Configuration**: Flexible time slot management
- **Interactive Routine Table**: Drag-and-drop style schedule creation
- **Data Export/Import**: JSON format for backup and transfer
- **Print Support**: Professional printing layout
- **Search Functionality**: Filter rooms by number
- **Real-time Statistics**: Track rooms, schedules, and teachers

### 👨‍🎓 Student Portal
- **Class-wise Schedules**: View schedules for all classes or filter by specific class
- **Color-coded Subjects**: Visual distinction between different subjects
- **Today's Classes**: Highlighted current day schedule
- **Auto-refresh**: Keeps data synchronized
- **Responsive Design**: Works on all devices
- **Print Support**: Student-friendly schedule printing

### 👨‍🏫 Teacher Portal
- **Individual Teacher Schedules**: Personal weekly timetables
- **Workload Analysis**: Track teaching hours and distribution
- **Subject Statistics**: Overview of subjects taught
- **Today's Classes**: Current day teaching schedule
- **Teacher Search**: Quick teacher lookup
- **Detailed Analytics**: Classes taught, rooms used, and more

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Node.js (for development)

### Installation

1. **Clone or Download** the project
2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Build CSS** (for development):
   ```bash
   npm run dev
   ```

4. **Build for Production**:
   ```bash
   npm run build
   ```

5. **Serve Locally** (optional):
   ```bash
   npm run serve
   ```

6. **Open in Browser**:
   - Open `index.html` in your web browser
   - Or visit `http://localhost:3000` if using the serve command

## 📁 Project Structure

```
School_Routine_Management/
├── index.html                 # Main entry point
├── input.css                  # Tailwind CSS source
├── output.css                 # Generated CSS
├── package.json              # Project configuration
├── src/
│   ├── components/
│   │   └── components.js      # Reusable UI components
│   ├── data/
│   │   └── routineData.js     # Default data and constants
│   ├── pages/
│   │   ├── admin.html         # Administration panel
│   │   ├── student.html       # Student portal
│   │   └── teacher.html       # Teacher portal
│   └── utils/
│       └── dataManager.js     # Data management utilities
└── README.md                 # This file
```

## 🎨 Design Features

### Color Scheme
- **Administration**: Blue theme (#3B82F6)
- **Student Portal**: Green theme (#10B981)
- **Teacher Portal**: Purple theme (#8B5CF6)

### Room Categories
- **Classroom**: 🟩 Green
- **Lab**: 🟦 Blue
- **Other**: 🟨 Yellow

### Responsive Design
- Mobile-first approach
- Tablet and desktop optimized
- Touch-friendly interface

## 💾 Data Management

### Storage
- Uses browser's **localStorage** for data persistence
- JSON format for easy backup and transfer
- Automatic data initialization with sample data

### Data Structure
- **Rooms**: ID, number, category, details
- **Time Slots**: ID, start time, end time, label
- **Schedules**: ID, room, day, time slot, subject, class, teacher, remarks

## 🛠️ Technical Features

### Components
- **Modal System**: Reusable popup windows
- **Form Builder**: Dynamic form generation
- **Data Table**: Sortable, searchable tables
- **Toast Notifications**: User feedback system
- **Loading Indicators**: Progress feedback

### Accessibility
- Keyboard navigation support
- Screen reader friendly
- High contrast mode support
- Focus indicators
- ARIA labels

### Performance
- Optimized CSS with Tailwind
- Minimal JavaScript dependencies
- Efficient DOM manipulation
- Local storage for fast access

## 🎯 Usage Guide

### For Administrators
1. **Add Rooms**: Use the Room Management panel to add classrooms, labs, etc.
2. **Configure Time Slots**: Set up your school's period timings
3. **Create Schedules**: Click "Add Schedule" in any time slot to assign classes
4. **Export Data**: Backup your schedules using the Export button
5. **Print Schedules**: Generate printer-friendly timetables

### For Students
1. **Select Class**: Filter by specific class or view all classes
2. **View Schedule**: See weekly timetable with color-coded subjects
3. **Check Today's Classes**: View current day's schedule
4. **Print Schedule**: Generate class schedule printouts

### For Teachers
1. **Select Teacher**: Choose from the teacher list
2. **View Personal Schedule**: See individual weekly timetable
3. **Check Workload**: Review teaching hours and distribution
4. **Today's Classes**: View current day's teaching schedule

## 🔧 Customization

### Adding New Features
- Extend `dataManager.js` for new data operations
- Add components to `components.js` for UI elements
- Modify CSS in `input.css` for styling changes

### Configuration
- Update `routineData.js` for default data
- Modify time slots, subjects, and classes as needed
- Customize room categories and colors

## 📱 Browser Support

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

## 🎉 Features Highlights

### Advanced Functionality
- 📊 **Real-time Statistics**: Live data updates
- 🔍 **Smart Search**: Filter and find quickly
- 🎨 **Dark Mode**: Toggle between light/dark themes
- 📱 **Mobile Responsive**: Works on all screen sizes
- 🖨️ **Print Support**: Professional printouts
- 💾 **Data Export/Import**: Backup and restore
- 🔄 **Auto-sync**: Automatic data refresh
- 🎯 **User-friendly**: Intuitive interface design

### Security & Data
- 🔒 Client-side storage (no server required)
- 🛡️ Data validation and error handling
- 🔄 Automatic backup recommendations
- 📋 Import/export for data portability

## 🆘 Troubleshooting

### Common Issues
1. **Styles not loading**: Run `npm run build` to regenerate CSS
2. **Data not saving**: Check browser localStorage permissions
3. **Print issues**: Use Chrome for best print results
4. **Mobile display**: Clear browser cache if layout issues occur

### Reset Data
1. Open browser developer tools (F12)
2. Go to Application/Storage tab
3. Clear localStorage for the site
4. Refresh the page

## 🤝 Contributing

This is a complete, production-ready system. Feel free to:
- Customize for your school's needs
- Add new features and enhancements
- Report issues or suggest improvements
- Create themes and extensions

## 📄 License

MIT License - Feel free to use and modify for your educational institution.

## 🎓 Credits

Built with modern web technologies:
- **Tailwind CSS** for styling
- **Font Awesome** for icons
- **Vanilla JavaScript** for functionality
- **Local Storage** for data persistence

---

**Developed for educational institutions to streamline schedule management and improve academic organization.** 🏫✨