// Modal Component for various forms and displays
class Modal {
    constructor(id, title = '', size = 'md') {
        this.id = id;
        this.title = title;
        this.size = size;
        this.isOpen = false;
        this.onClose = null;
        this.onSave = null;
        this.createModal();
    }

    createModal() {
        const sizeClasses = {
            sm: 'max-w-md',
            md: 'max-w-2xl',
            lg: 'max-w-4xl',
            xl: 'max-w-6xl'
        };

        const modalHTML = `
            <div id="${this.id}" class="modal-overlay fixed inset-0 bg-gray-900 bg-opacity-40 backdrop-blur-sm overflow-y-auto h-full w-full z-50 hidden">
                <div id="${this.id}-panel" class="modal-panel relative mx-auto my-16 ${sizeClasses[this.size]}">
                    <div class="bg-white rounded-xl shadow-2xl ring-1 ring-black ring-opacity-5">
                        <div class="flex items-center justify-between px-6 py-4 border-b">
                            <div class="flex items-center space-x-3">
                                <span class="inline-flex items-center justify-center h-9 w-9 rounded-lg bg-blue-100 text-blue-600">
                                    <i class="fas fa-window-maximize"></i>
                                </span>
                                <h3 class="text-lg font-semibold text-gray-900" id="${this.id}-title">${this.title}</h3>
                            </div>
                            <button class="modal-close p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    aria-label="Close"
                                    onclick="window.modals['${this.id}'].close()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="px-6 py-5" id="${this.id}-content">
                            <!-- Content will be inserted here -->
                        </div>
                        <div class="flex items-center justify-end px-6 py-4 border-t space-x-3 bg-gray-50" id="${this.id}-footer">
                            <button type="button" class="inline-flex items-center px-4 py-2 text-sm font-medium rounded-md text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    onclick="window.modals['${this.id}'].close()">
                                Cancel
                            </button>
                            <button type="button" class="inline-flex items-center px-4 py-2 text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    id="${this.id}-save-btn">
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        const saveBtn = document.getElementById(`${this.id}-save-btn`);
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                if (this.onSave) this.onSave();
            });
        }

        // Close modal when clicking outside panel
        const overlayEl = document.getElementById(this.id);
        overlayEl.addEventListener('click', (e) => {
            if (e.target.id === this.id) {
                this.close();
            }
        });

        // Register modal globally
        if (!window.modals) window.modals = {};
        window.modals[this.id] = this;
    }

    setContent(content) {
        document.getElementById(`${this.id}-content`).innerHTML = content;
    }

    setTitle(title) {
        document.getElementById(`${this.id}-title`).textContent = title;
    }

    setFooter(content) {
        document.getElementById(`${this.id}-footer`).innerHTML = content;
    }

    open() {
        const overlay = document.getElementById(this.id);
        const panel = document.getElementById(`${this.id}-panel`);
        overlay.classList.remove('hidden');
        overlay.classList.add('open');
        if (panel) panel.classList.add('open');
        this.isOpen = true;
        document.body.style.overflow = 'hidden';
    }

    close() {
        const overlay = document.getElementById(this.id);
        const panel = document.getElementById(`${this.id}-panel`);
        overlay.classList.remove('open');
        if (panel) panel.classList.remove('open');
        // Delay hide to allow animation
        setTimeout(() => {
            overlay.classList.add('hidden');
        }, 160);
        this.isOpen = false;
        document.body.style.overflow = '';
        if (this.onClose) this.onClose();
    }

    destroy() {
        const modal = document.getElementById(this.id);
        if (modal) {
            modal.remove();
        }
        if (window.modals && window.modals[this.id]) {
            delete window.modals[this.id];
        }
    }
}

// Form Builder Component
class FormBuilder {
    constructor(containerId) {
        this.containerId = containerId;
        this.fields = [];
        this.data = {};
    }

    addField(field) {
        this.fields.push(field);
        return this;
    }

    setData(data) {
        this.data = data;
        return this;
    }

    render() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        let formHTML = '<form class="space-y-4">';
        
        this.fields.forEach(field => {
            formHTML += this.renderField(field);
        });

        formHTML += '</form>';
        container.innerHTML = formHTML;

        // Populate form with data
        this.populateForm();
    }

    renderField(field) {
        const { type, name, label, placeholder, options, required, className } = field;
        const value = this.data[name] || '';
        const fieldId = `field-${name}`;
        const requiredMark = required ? '<span class="text-red-500">*</span>' : '';

        let fieldHTML = `
            <div class="${className || ''}">
                <label for="${fieldId}" class="block text-sm font-medium text-gray-700 mb-1">
                    ${label} ${requiredMark}
                </label>
        `;

        switch (type) {
            case 'text':
            case 'email':
            case 'password':
            case 'time':
                fieldHTML += `
                    <input type="${type}" id="${fieldId}" name="${name}" 
                           placeholder="${placeholder || ''}" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           ${required ? 'required' : ''} value="${value}">
                `;
                break;

            case 'select':
                fieldHTML += `<select id="${fieldId}" name="${name}" 
                             class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                             ${required ? 'required' : ''}>`;
                if (placeholder) {
                    fieldHTML += `<option value="">${placeholder}</option>`;
                }
                options?.forEach(option => {
                    const optionValue = typeof option === 'object' ? option.value : option;
                    const optionLabel = typeof option === 'object' ? option.label : option;
                    const selected = value === optionValue ? 'selected' : '';
                    fieldHTML += `<option value="${optionValue}" ${selected}>${optionLabel}</option>`;
                });
                fieldHTML += '</select>';
                break;

            case 'textarea':
                fieldHTML += `
                    <textarea id="${fieldId}" name="${name}" rows="3"
                              placeholder="${placeholder || ''}"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              ${required ? 'required' : ''}>${value}</textarea>
                `;
                break;

            case 'radio':
                options?.forEach((option, index) => {
                    const optionValue = typeof option === 'object' ? option.value : option;
                    const optionLabel = typeof option === 'object' ? option.label : option;
                    const checked = value === optionValue ? 'checked' : '';
                    fieldHTML += `
                        <div class="flex items-center">
                            <input type="radio" id="${fieldId}-${index}" name="${name}" value="${optionValue}" 
                                   class="mr-2" ${checked}>
                            <label for="${fieldId}-${index}" class="text-sm text-gray-700">${optionLabel}</label>
                        </div>
                    `;
                });
                break;

            case 'checkbox':
                const checked = value ? 'checked' : '';
                fieldHTML += `
                    <div class="flex items-center">
                        <input type="checkbox" id="${fieldId}" name="${name}" value="1" 
                               class="mr-2" ${checked}>
                        <label for="${fieldId}" class="text-sm text-gray-700">${placeholder || label}</label>
                    </div>
                `;
                break;
        }

        fieldHTML += '</div>';
        return fieldHTML;
    }

    populateForm() {
        Object.keys(this.data).forEach(key => {
            const element = document.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = !!this.data[key];
                } else if (element.type === 'radio') {
                    const radio = document.querySelector(`[name="${key}"][value="${this.data[key]}"]`);
                    if (radio) radio.checked = true;
                } else {
                    element.value = this.data[key];
                }
            }
        });
    }

    getFormData() {
        const form = document.querySelector(`#${this.containerId} form`);
        if (!form) return {};

        const formData = new FormData(form);
        const data = {};

        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }

        // Handle checkboxes that aren't checked
        this.fields.forEach(field => {
            if (field.type === 'checkbox' && !data[field.name]) {
                data[field.name] = false;
            }
        });

        return data;
    }

    validate() {
        const form = document.querySelector(`#${this.containerId} form`);
        return form ? form.checkValidity() : false;
    }
}

// Table Component
class DataTable {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.options = {
            columns: [],
            data: [],
            searchable: false,
            sortable: false,
            pagination: false,
            pageSize: 10,
            actions: [],
            className: 'min-w-full divide-y divide-gray-200',
            ...options
        };
        this.currentPage = 1;
        this.sortColumn = null;
        this.sortDirection = 'asc';
        this.searchTerm = '';
    }

    setData(data) {
        this.options.data = data;
        this.render();
    }

    setColumns(columns) {
        this.options.columns = columns;
        this.render();
    }

    render() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        let html = '';

        // Add search if enabled
        if (this.options.searchable) {
            html += this.renderSearch();
        }

        // Table
        html += `<div class="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">`;
        html += `<table class="${this.options.className}">`;
        html += this.renderHeader();
        html += this.renderBody();
        html += '</table>';
        html += '</div>';

        // Pagination
        if (this.options.pagination) {
            html += this.renderPagination();
        }

        container.innerHTML = html;
        this.attachEventListeners();
    }

    renderSearch() {
        return `
            <div class="mb-4">
                <div class="relative">
                    <input type="text" id="${this.containerId}-search" 
                           placeholder="Search..." 
                           class="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           value="${this.searchTerm}">
                    <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                </div>
            </div>
        `;
    }

    renderHeader() {
        let headerHTML = '<thead class="bg-gray-50"><tr>';
        
        this.options.columns.forEach(column => {
            const sortIcon = this.sortColumn === column.key 
                ? (this.sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down')
                : 'fa-sort';

            headerHTML += `
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    ${this.options.sortable ? 
                        `<button class="flex items-center space-x-1 hover:text-gray-700" onclick="window.tables['${this.containerId}'].sort('${column.key}')">
                            <span>${column.label}</span>
                            <i class="fas ${sortIcon}"></i>
                        </button>` :
                        column.label
                    }
                </th>
            `;
        });

        if (this.options.actions.length > 0) {
            headerHTML += '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>';
        }

        headerHTML += '</tr></thead>';
        return headerHTML;
    }

    renderBody() {
        const data = this.getFilteredData();
        let bodyHTML = '<tbody class="bg-white divide-y divide-gray-100">';

        if (data.length === 0) {
            bodyHTML += `
                <tr>
                    <td colspan="${this.options.columns.length + (this.options.actions.length > 0 ? 1 : 0)}" 
                        class="px-6 py-12 text-center text-gray-500">
                        <i class="fas fa-inbox text-4xl mb-4 text-gray-300 block"></i>
                        No data available
                    </td>
                </tr>
            `;
        } else {
            data.forEach((row, index) => {
                bodyHTML += '<tr class="hover:bg-gray-50 transition-colors">';
                
                this.options.columns.forEach(column => {
                    let cellContent = row[column.key];
                    
                    if (column.render) {
                        cellContent = column.render(row[column.key], row, index);
                    }
                    
                    bodyHTML += `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${cellContent}</td>`;
                });

                if (this.options.actions.length > 0) {
                    bodyHTML += '<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">';
                    bodyHTML += '<div class="flex space-x-2">';
                    
                    this.options.actions.forEach(action => {
                        bodyHTML += `
                            <button onclick="${action.onClick}(${JSON.stringify(row).replace(/"/g, '&quot;')})" 
                                    class="${action.className || 'text-blue-600 hover:text-blue-900'}"
                                    title="${action.title || ''}">
                                <i class="${action.icon}"></i>
                            </button>
                        `;
                    });
                    
                    bodyHTML += '</div>';
                    bodyHTML += '</td>';
                }

                bodyHTML += '</tr>';
            });
        }

        bodyHTML += '</tbody>';
        return bodyHTML;
    }

    renderPagination() {
        const data = this.getFilteredData();
        const totalPages = Math.ceil(data.length / this.options.pageSize);
        
        if (totalPages <= 1) return '';

        let paginationHTML = `
            <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6 mt-4">
                <div class="flex-1 flex justify-between sm:hidden">
                    <button onclick="window.tables['${this.containerId}'].previousPage()" 
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 ${this.currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''}"
                            ${this.currentPage === 1 ? 'disabled' : ''}>
                        Previous
                    </button>
                    <button onclick="window.tables['${this.containerId}'].nextPage()" 
                            class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 ${this.currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''}"
                            ${this.currentPage === totalPages ? 'disabled' : ''}>
                        Next
                    </button>
                </div>
                <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                        <p class="text-sm text-gray-700">
                            Showing
                            <span class="font-medium">${(this.currentPage - 1) * this.options.pageSize + 1}</span>
                            to
                            <span class="font-medium">${Math.min(this.currentPage * this.options.pageSize, data.length)}</span>
                            of
                            <span class="font-medium">${data.length}</span>
                            results
                        </p>
                    </div>
                    <div>
                        <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                            <button onclick="window.tables['${this.containerId}'].previousPage()" 
                                    class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ${this.currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''}"
                                    ${this.currentPage === 1 ? 'disabled' : ''}>
                                <i class="fas fa-chevron-left"></i>
                            </button>
        `;

        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            if (i === this.currentPage) {
                paginationHTML += `
                    <span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-blue-50 text-sm font-medium text-blue-600">
                        ${i}
                    </span>
                `;
            } else {
                paginationHTML += `
                    <button onclick="window.tables['${this.containerId}'].goToPage(${i})" 
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                        ${i}
                    </button>
                `;
            }
        }

        paginationHTML += `
                            <button onclick="window.tables['${this.containerId}'].nextPage()" 
                                    class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ${this.currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''}"
                                    ${this.currentPage === totalPages ? 'disabled' : ''}>
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </nav>
                    </div>
                </div>
            </div>
        `;

        return paginationHTML;
    }

    getFilteredData() {
        let data = [...this.options.data];

        // Apply search filter
        if (this.searchTerm) {
            data = data.filter(row => {
                return this.options.columns.some(column => {
                    const value = row[column.key];
                    return value && value.toString().toLowerCase().includes(this.searchTerm.toLowerCase());
                });
            });
        }

        // Apply sorting
        if (this.sortColumn) {
            data.sort((a, b) => {
                const aVal = a[this.sortColumn];
                const bVal = b[this.sortColumn];
                
                if (aVal < bVal) return this.sortDirection === 'asc' ? -1 : 1;
                if (aVal > bVal) return this.sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }

        // Apply pagination
        if (this.options.pagination) {
            const start = (this.currentPage - 1) * this.options.pageSize;
            const end = start + this.options.pageSize;
            data = data.slice(start, end);
        }

        return data;
    }

    attachEventListeners() {
        // Search functionality
        if (this.options.searchable) {
            const searchInput = document.getElementById(`${this.containerId}-search`);
            if (searchInput) {
                searchInput.addEventListener('input', (e) => {
                    this.searchTerm = e.target.value;
                    this.currentPage = 1;
                    this.render();
                });
            }
        }

        // Register table globally for pagination and sorting
        if (!window.tables) window.tables = {};
        window.tables[this.containerId] = this;
    }

    sort(column) {
        if (this.sortColumn === column) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortColumn = column;
            this.sortDirection = 'asc';
        }
        this.render();
    }

    goToPage(page) {
        this.currentPage = page;
        this.render();
    }

    nextPage() {
        const totalPages = Math.ceil(this.getFilteredData().length / this.options.pageSize);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.render();
        }
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.render();
        }
    }
}

// Toast Notification Component
class Toast {
    static show(message, type = 'info', duration = 3000) {
        const toastContainer = Toast.getOrCreateContainer();
        
        const toast = document.createElement('div');
        toast.className = `toast-item transform transition-all duration-300 ease-in-out ${Toast.getTypeClasses(type)}`;
        
        toast.innerHTML = `
            <div class="flex items-center">
                <i class="fas ${Toast.getTypeIcon(type)} mr-3"></i>
                <span class="flex-1">${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-3 text-white hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        toastContainer.appendChild(toast);

        // Trigger animation
        setTimeout(() => {
            toast.classList.add('toast-show');
        }, 10);

        // Auto remove
        if (duration > 0) {
            setTimeout(() => {
                Toast.remove(toast);
            }, duration);
        }
    }

    static remove(toast) {
        toast.classList.remove('toast-show');
        setTimeout(() => {
            if (toast.parentElement) {
                toast.parentElement.removeChild(toast);
            }
        }, 300);
    }

    static getOrCreateContainer() {
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'fixed top-4 right-4 z-50 space-y-2';
            document.body.appendChild(container);
        }
        return container;
    }

    static getTypeClasses(type) {
        const classes = {
            success: 'bg-green-500 text-white shadow-lg rounded-lg p-4 max-w-md',
            error: 'bg-red-500 text-white shadow-lg rounded-lg p-4 max-w-md',
            warning: 'bg-yellow-500 text-white shadow-lg rounded-lg p-4 max-w-md',
            info: 'bg-blue-500 text-white shadow-lg rounded-lg p-4 max-w-md'
        };
        return classes[type] || classes.info;
    }

    static getTypeIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[type] || icons.info;
    }
}

// Loading Component
class Loading {
    static show(message = 'Loading...') {
        Loading.hide(); // Remove any existing loading

        const loadingHTML = `
            <div id="loading-overlay" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
                <div class="bg-white p-8 rounded-lg shadow-lg text-center">
                    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p class="text-gray-700">${message}</p>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', loadingHTML);
        document.body.style.overflow = 'hidden';
    }

    static hide() {
        const loading = document.getElementById('loading-overlay');
        if (loading) {
            loading.remove();
            document.body.style.overflow = '';
        }
    }
}

// Add CSS for toast animations
const style = document.createElement('style');
style.textContent = `
    .toast-item { opacity: 0; transform: translateX(100%); }
    .toast-show { opacity: 1; transform: translateX(0); }
    /* Modal entrance/exit */
    .modal-overlay.open { animation: overlayFadeIn 160ms ease-out; }
    .modal-panel { opacity: 0; transform: translateY(12px) scale(0.98); }
    .modal-panel.open { opacity: 1; transform: translateY(0) scale(1); transition: opacity 160ms ease-out, transform 160ms ease-out; }
    @keyframes overlayFadeIn { from { opacity: 0; } to { opacity: 1; } }
`;
document.head.appendChild(style);