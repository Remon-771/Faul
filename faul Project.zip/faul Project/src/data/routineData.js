// Data structure definitions and default data
const DEFAULT_DATA = {
    rooms: [
        { id: 1, number: 'R001', category: 'classroom', details: 'Main classroom for grade 1-2' },
        { id: 2, number: 'R002', category: 'classroom', details: 'Main classroom for grade 3-4' },
        { id: 3, number: 'L001', category: 'lab', details: 'Science Laboratory' },
        { id: 4, number: 'L002', category: 'lab', details: 'Computer Laboratory' },
        { id: 5, number: 'A001', category: 'other', details: 'Assembly Hall' }
    ],
    timeSlots: [
        { id: 1, startTime: '08:00', endTime: '09:00', label: '08:00 - 09:00' },
        { id: 2, startTime: '09:00', endTime: '10:00', label: '09:00 - 10:00' },
        { id: 3, startTime: '10:00', endTime: '11:00', label: '10:00 - 11:00' },
        { id: 4, startTime: '11:00', endTime: '12:00', label: '11:00 - 12:00' },
        { id: 5, startTime: '12:00', endTime: '13:00', label: '12:00 - 13:00 (Lunch)' },
        { id: 6, startTime: '13:00', endTime: '14:00', label: '13:00 - 14:00' },
        { id: 7, startTime: '14:00', endTime: '15:00', label: '14:00 - 15:00' }
    ],
    schedules: [
        {
            id: 1,
            roomNumber: 'R001',
            day: 'monday',
            timeSlotId: 1,
            subject: 'Mathematics',
            class: '5',
            teacher: 'John Smith',
            remarks: 'Basic Algebra'
        },
        {
            id: 2,
            roomNumber: 'R001',
            day: 'monday',
            timeSlotId: 2,
            subject: 'English',
            class: '5',
            teacher: 'Jane Doe',
            remarks: 'Grammar lesson'
        }
    ],
    subjects: [
        'Mathematics', 'English', 'Science', 'Social Studies', 'Physics', 
        'Chemistry', 'Biology', 'History', 'Geography', 'Computer Science',
        'Physical Education', 'Art', 'Music', 'Literature'
    ],
    classes: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
    days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
};

// Room categories with their colors
const ROOM_CATEGORIES = {
    classroom: { label: 'Class Room', color: 'green', bgColor: 'bg-emerald-100', textColor: 'text-emerald-800' },
    lab: { label: 'Lab', color: 'blue', bgColor: 'bg-blue-100', textColor: 'text-blue-800' },
    other: { label: 'Other Facility', color: 'orange', bgColor: 'bg-orange-100', textColor: 'text-orange-800' }
};

// Day labels for display
const DAY_LABELS = {
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday'
};

// Export default data for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DEFAULT_DATA, ROOM_CATEGORIES, DAY_LABELS };
}