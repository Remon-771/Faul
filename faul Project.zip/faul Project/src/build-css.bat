@echo off
echo ========================================
echo  Tailwind CSS - Watch Mode
echo ========================================
echo.
echo Starting Tailwind CSS compiler...
echo Your CSS will auto-rebuild on changes.
echo Press Ctrl+C to stop.
echo.

cd /d "%~dp0"
npx -y @tailwindcss/cli@latest -i ./input.css -o ./output.css --watch
