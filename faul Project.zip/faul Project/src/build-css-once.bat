@echo off
echo ========================================
echo  Tailwind CSS - Single Build
echo ========================================
echo.
echo Building optimized CSS file...
echo.

cd /d "%~dp0"
npx -y @tailwindcss/cli@latest -i ./input.css -o ./output.css --minify

echo.
echo ========================================
echo  Build Complete!
echo ========================================
pause
