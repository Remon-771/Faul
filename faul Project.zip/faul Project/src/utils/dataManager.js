// Data Manager - Handles all localStorage operations and data management
class DataManager {
    constructor() {
        this.initializeData();
    }

    // Initialize data with defaults if not exists
    initializeData() {
        if (!localStorage.getItem('rooms')) {
            this.setRooms(DEFAULT_DATA.rooms);
        }
        if (!localStorage.getItem('timeSlots')) {
            this.setTimeSlots(DEFAULT_DATA.timeSlots);
        }
        if (!localStorage.getItem('schedules')) {
            this.setSchedules(DEFAULT_DATA.schedules);
        }
        if (!localStorage.getItem('subjects')) {
            this.setSubjects(DEFAULT_DATA.subjects);
        }
    }

    // Room Management
    getRooms() {
        try {
            return JSON.parse(localStorage.getItem('rooms') || '[]');
        } catch (error) {
            console.error('Error getting rooms:', error);
            return [];
        }
    }

    setRooms(rooms) {
        localStorage.setItem('rooms', JSON.stringify(rooms));
    }

    addRoom(room) {
        const rooms = this.getRooms();
        const newId = Math.max(...rooms.map(r => r.id), 0) + 1;
        const newRoom = { ...room, id: newId };
        rooms.push(newRoom);
        this.setRooms(rooms);
        return newRoom;
    }

    updateRoom(roomId, updatedRoom) {
        const rooms = this.getRooms();
        const index = rooms.findIndex(r => r.id === roomId);
        if (index !== -1) {
            rooms[index] = { ...rooms[index], ...updatedRoom };
            this.setRooms(rooms);
            return rooms[index];
        }
        return null;
    }

    deleteRoom(roomId) {
        const rooms = this.getRooms();
        const filteredRooms = rooms.filter(r => r.id !== roomId);
        this.setRooms(filteredRooms);
        
        // Also delete all schedules for this room
        const schedules = this.getSchedules();
        const room = rooms.find(r => r.id === roomId);
        if (room) {
            const filteredSchedules = schedules.filter(s => s.roomNumber !== room.number);
            this.setSchedules(filteredSchedules);
        }
    }

    // Time Slot Management
    getTimeSlots() {
        try {
            return JSON.parse(localStorage.getItem('timeSlots') || '[]');
        } catch (error) {
            console.error('Error getting time slots:', error);
            return [];
        }
    }

    setTimeSlots(timeSlots) {
        localStorage.setItem('timeSlots', JSON.stringify(timeSlots));
    }

    addTimeSlot(timeSlot) {
        const timeSlots = this.getTimeSlots();
        const newId = Math.max(...timeSlots.map(t => t.id), 0) + 1;
        const newTimeSlot = { ...timeSlot, id: newId };
        timeSlots.push(newTimeSlot);
        this.setTimeSlots(timeSlots);
        return newTimeSlot;
    }

    updateTimeSlot(timeSlotId, updatedTimeSlot) {
        const timeSlots = this.getTimeSlots();
        const index = timeSlots.findIndex(t => t.id === timeSlotId);
        if (index !== -1) {
            timeSlots[index] = { ...timeSlots[index], ...updatedTimeSlot };
            this.setTimeSlots(timeSlots);
            return timeSlots[index];
        }
        return null;
    }

    deleteTimeSlot(timeSlotId) {
        const timeSlots = this.getTimeSlots();
        const filteredTimeSlots = timeSlots.filter(t => t.id !== timeSlotId);
        this.setTimeSlots(filteredTimeSlots);
        
        // Also delete all schedules for this time slot
        const schedules = this.getSchedules();
        const filteredSchedules = schedules.filter(s => s.timeSlotId !== timeSlotId);
        this.setSchedules(filteredSchedules);
    }

    // Schedule Management
    getSchedules() {
        try {
            return JSON.parse(localStorage.getItem('schedules') || '[]');
        } catch (error) {
            console.error('Error getting schedules:', error);
            return [];
        }
    }

    setSchedules(schedules) {
        localStorage.setItem('schedules', JSON.stringify(schedules));
    }

    addSchedule(schedule) {
        const schedules = this.getSchedules();
        const newId = Math.max(...schedules.map(s => s.id), 0) + 1;
        const newSchedule = { ...schedule, id: newId };
        schedules.push(newSchedule);
        this.setSchedules(schedules);
        return newSchedule;
    }

    updateSchedule(scheduleId, updatedSchedule) {
        const schedules = this.getSchedules();
        const index = schedules.findIndex(s => s.id === scheduleId);
        if (index !== -1) {
            schedules[index] = { ...schedules[index], ...updatedSchedule };
            this.setSchedules(schedules);
            return schedules[index];
        }
        return null;
    }

    deleteSchedule(scheduleId) {
        const schedules = this.getSchedules();
        const filteredSchedules = schedules.filter(s => s.id !== scheduleId);
        this.setSchedules(filteredSchedules);
    }

    // Get schedules for specific room and day
    getSchedulesForRoomAndDay(roomNumber, day) {
        const schedules = this.getSchedules();
        return schedules.filter(s => s.roomNumber === roomNumber && s.day === day);
    }

    // Get schedules for specific class
    getSchedulesForClass(className) {
        const schedules = this.getSchedules();
        return schedules.filter(s => s.class === className);
    }

    // Get schedules for specific teacher
    getSchedulesForTeacher(teacherName) {
        const schedules = this.getSchedules();
        return schedules.filter(s => s.teacher === teacherName);
    }

    // Subject Management
    getSubjects() {
        try {
            return JSON.parse(localStorage.getItem('subjects') || '[]');
        } catch (error) {
            console.error('Error getting subjects:', error);
            return DEFAULT_DATA.subjects;
        }
    }

    setSubjects(subjects) {
        localStorage.setItem('subjects', JSON.stringify(subjects));
    }

    addSubject(subject) {
        const subjects = this.getSubjects();
        if (!subjects.includes(subject)) {
            subjects.push(subject);
            this.setSubjects(subjects);
        }
    }

    // Get all unique teachers
    getAllTeachers() {
        const schedules = this.getSchedules();
        const teachers = [...new Set(schedules.map(s => s.teacher).filter(t => t && t.trim() !== ''))];
        return teachers.sort();
    }

    // Data Export/Import
    exportData() {
        const data = {
            rooms: this.getRooms(),
            timeSlots: this.getTimeSlots(),
            schedules: this.getSchedules(),
            subjects: this.getSubjects(),
            exportDate: new Date().toISOString()
        };
        return JSON.stringify(data, null, 2);
    }

    importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            
            if (data.rooms) this.setRooms(data.rooms);
            if (data.timeSlots) this.setTimeSlots(data.timeSlots);
            if (data.schedules) this.setSchedules(data.schedules);
            if (data.subjects) this.setSubjects(data.subjects);
            
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }

    // Clear all data
    clearAllData() {
        localStorage.removeItem('rooms');
        localStorage.removeItem('timeSlots');
        localStorage.removeItem('schedules');
        localStorage.removeItem('subjects');
        this.initializeData();
    }

    // Search functionality
    searchSchedules(query) {
        const schedules = this.getSchedules();
        const lowercaseQuery = query.toLowerCase();
        
        return schedules.filter(schedule => 
            schedule.subject.toLowerCase().includes(lowercaseQuery) ||
            schedule.teacher.toLowerCase().includes(lowercaseQuery) ||
            schedule.class.toLowerCase().includes(lowercaseQuery) ||
            schedule.roomNumber.toLowerCase().includes(lowercaseQuery) ||
            (schedule.remarks && schedule.remarks.toLowerCase().includes(lowercaseQuery))
        );
    }

    // Get routine table data for admin view
    getRoutineTableData() {
        const rooms = this.getRooms();
        const schedules = this.getSchedules();
        const timeSlots = this.getTimeSlots();
        const days = DEFAULT_DATA.days;

        const tableData = {};
        
        rooms.forEach(room => {
            tableData[room.number] = {};
            days.forEach(day => {
                tableData[room.number][day] = schedules.filter(s => 
                    s.roomNumber === room.number && s.day === day
                );
            });
        });

        return tableData;
    }

    // Get class-wise schedule for student view
    getClassRoutine(className) {
        const schedules = this.getSchedulesForClass(className);
        const timeSlots = this.getTimeSlots();
        const days = DEFAULT_DATA.days;

        const routine = {};
        days.forEach(day => {
            routine[day] = {};
            timeSlots.forEach(slot => {
                const schedule = schedules.find(s => s.day === day && s.timeSlotId === slot.id);
                routine[day][slot.id] = schedule || null;
            });
        });

        return routine;
    }

    // Get teacher-wise schedule
    getTeacherRoutine(teacherName) {
        const schedules = this.getSchedulesForTeacher(teacherName);
        const timeSlots = this.getTimeSlots();
        const days = DEFAULT_DATA.days;

        const routine = {};
        days.forEach(day => {
            routine[day] = {};
            timeSlots.forEach(slot => {
                const schedule = schedules.find(s => s.day === day && s.timeSlotId === slot.id);
                routine[day][slot.id] = schedule || null;
            });
        });

        return routine;
    }
}

// Create global instance
const dataManager = new DataManager();