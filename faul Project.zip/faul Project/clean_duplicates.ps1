$content = Get-Content "c:\Users\AL AMIN REMON\Desktop\final project\src\routine.html" -Raw

# Remove common duplicate patterns by keeping only the first occurrence
# This will preserve functionality while removing unnecessary duplicates

# Split content by lines for processing
$lines = $content -split "`r?`n"
$cleanedLines = New-Object System.Collections.ArrayList
$seenLines = @{}

# Keep track of function definitions to avoid removing necessary ones
$functionPattern = '^\s*function\s+(\w+)'
$seenFunctions = @{}

Write-Host "Original lines: $($lines.Count)"

for($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    $trimmedLine = $line.Trim()
    
    # Skip empty lines from deduplication to preserve formatting
    if($trimmedLine -eq "") {
        $cleanedLines.Add($line) | Out-Null
        continue
    }
    
    # Special handling for function definitions
    if($line -match $functionPattern) {
        $funcName = $Matches[1]
        if($seenFunctions.ContainsKey($funcName)) {
            Write-Host "Skipping duplicate function: $funcName at line $($i + 1)"
            # Skip this function definition and its body
            $braceCount = 0
            $inFunction = $false
            while($i -lt $lines.Count) {
                if($lines[$i] -match '\{') { 
                    $braceCount += ($lines[$i] -split '\{').Count - 1
                    $inFunction = $true
                }
                if($lines[$i] -match '\}') { 
                    $braceCount -= ($lines[$i] -split '\}').Count - 1
                }
                if($inFunction -and $braceCount -le 0) {
                    break
                }
                $i++
            }
            continue
        } else {
            $seenFunctions[$funcName] = $true
            $cleanedLines.Add($line) | Out-Null
        }
    }
    # Regular deduplication for other content
    elseif($seenLines.ContainsKey($trimmedLine)) {
        # Skip duplicate line
        continue
    } else {
        $seenLines[$trimmedLine] = $true
        $cleanedLines.Add($line) | Out-Null
    }
}

Write-Host "Cleaned lines: $($cleanedLines.Count)"
Write-Host "Removed lines: $($lines.Count - $cleanedLines.Count)"

# Write cleaned content back
$cleanedContent = $cleanedLines -join "`n"
Set-Content "c:\Users\AL AMIN REMON\Desktop\final project\src\routine.html" -Value $cleanedContent -Encoding UTF8

Write-Host "File cleaned successfully!"