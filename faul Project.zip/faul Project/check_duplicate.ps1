$content = Get-Content "c:\Users\AL AMIN REMON\Desktop\final project\src\routine.html"
$firstLine = $content[0]
Write-Host "First line: $firstLine"
Write-Host "Searching for duplicate of first line..."

for($i = 1; $i -lt $content.Count; $i++) {
    if($content[$i] -eq $firstLine) {
        Write-Host "Found duplicate at line: $($i + 1)"
        Write-Host "Next few lines:"
        $content[$i..($i + 5)] | ForEach-Object { Write-Host "  $_" }
        break
    }
}